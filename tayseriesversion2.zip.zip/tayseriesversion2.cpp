// ============================================================zzz
//  Approxima v2: Taylor Series Calculator (smarter methods)
//  Approximates sin x, cos x, e^x and ln(1+x) term by term and
//  shows the error shrinking. It also compares the CLASSIC method
//  (plain series) with the SMART method (reduce x first).
//
//  What is new in v2 (all three are "make x small first" ideas):
//   1. sin/cos : shrink the angle to [-pi/4, pi/4] (quarter turns)
//   2. e^x     : e^x = 2^k * e^r, with r small (|r| <= 0.35)
//   3. ln(1+x) : ln(1+x) = 2*(y + y^3/3 + y^5/5 + ...), y = x/(2+x)
//
//  Compile :  g++ -std=c++11 -Wall -Wextra -o approxima taylor_series_v2.cpp
//  Run     :  ./approxima        (Windows: approxima.exe)
// ============================================================
#include <iostream>
#include <iomanip>
#include <cmath>
#include <limits>
using namespace std;

const double PI        = 3.14159265358979323846;
const double LN2       = 0.69314718055994530942;
const int    MAX_TERMS = 50;
const double TOLERANCE = 1e-6;

// LN_ATANH is internal only (the faster log series). It is not a menu choice.
enum Func { SIN = 1, COS = 2, EXP = 3, LN = 4, LN_ATANH = 5 };

// Everything the series needs to know after x has been prepared.
struct Plan {
    Func   series;   // which series to run (sin may turn into cos, ...)
    double x;        // value fed into the series
    double sign;     // +1 or -1 applied to the result
    int    pow2;     // result is multiplied by 2^pow2  (used by e^x)
    bool   invert;   // classic method only: 1/result for negative e^x
};

// ---------- Series (each term is built from the previous term) ----------
//  sin x     : x - x^3/3! + x^5/5! - ...
//  cos x     : 1 - x^2/2! + x^4/4! - ...
//  e^x       : 1 + x + x^2/2! + ...
//  ln(1+x)   : x - x^2/2 + x^3/3 - ...            (classic, slow)
//  ln(1+x)   : 2*(y + y^3/3 + y^5/5 + ...)        (smart, fast)

double firstTerm(Func f, double x) {
    if (f == SIN) return x;
    if (f == COS) return 1.0;
    if (f == EXP) return 1.0;
    if (f == LN)  return x;
    return 2.0 * x;                                   // LN_ATANH
}

// k = index of the term being built (k >= 2), prev = term k-1
double nextTerm(Func f, int k, double prev, double x) {
    if (f == SIN) return prev * (-x * x) / ((2.0 * k - 2) * (2.0 * k - 1));
    if (f == COS) return prev * (-x * x) / ((2.0 * k - 3) * (2.0 * k - 2));
    if (f == EXP) return prev * x / (k - 1);
    if (f == LN)  return prev * (-x) * (k - 1) / k;
    return prev * x * x * (2.0 * k - 3) / (2.0 * k - 1);  // LN_ATANH
}

double exactValue(Func f, double x) {
    if (f == SIN) return sin(x);
    if (f == COS) return cos(x);
    if (f == EXP) return exp(x);
    return log(1.0 + x);                              // LN
}

const char* funcName(Func f) {
    if (f == SIN) return "sin(x)";
    if (f == COS) return "cos(x)";
    if (f == EXP) return "e^x";
    return "ln(1+x)";
}

// ---------- Safe input helpers ----------
bool readDouble(const char* prompt, double& value) {
    while (true) {
        cout << prompt;
        if (cin >> value && isfinite(value)) return true;
        if (cin.eof()) return false;
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "  Invalid input. Please enter a number.\n";
    }
}

bool readInt(const char* prompt, int lo, int hi, int& value) {
    while (true) {
        cout << prompt;
        if (cin >> value && value >= lo && value <= hi) return true;
        if (cin.eof()) return false;
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "  Please enter a whole number from " << lo << " to " << hi << ".\n";
    }
}

// ---------- Preparing x ----------
// CLASSIC: bring angle into [-pi, pi]; for negative e^x use 1/e^(-x).
double reduceAngle(double x) {
    x = fmod(x, 2.0 * PI);
    if (x >  PI) x -= 2.0 * PI;
    if (x < -PI) x += 2.0 * PI;
    return x;
}

// smart == true  : new v2 methods
// smart == false : classic v1 methods (kept so we can compare)
Plan prepare(Func f, double xo, bool smart) {
    Plan p;
    p.series = f;  p.x = xo;  p.sign = 1.0;  p.pow2 = 0;  p.invert = false;

    if (f == SIN || f == COS) {
        if (smart) {
            // Cut the angle into quarter turns: x = k*(pi/2) + r, |r| <= pi/4.
            long k = lround(xo / (PI / 2.0));
            int  q = static_cast<int>(((k % 4) + 4) % 4);   // quadrant 0..3
            p.x = xo - k * (PI / 2.0);
            bool swapSC = (q % 2 == 1);                      // odd quadrant: sin <-> cos
            if (f == SIN) {
                p.series = swapSC ? COS : SIN;
                p.sign   = (q >= 2) ? -1.0 : 1.0;
            } else {
                p.series = swapSC ? SIN : COS;
                p.sign   = (q == 1 || q == 2) ? -1.0 : 1.0;
            }
        } else {
            p.x = reduceAngle(xo);
        }
    }
    else if (f == EXP) {
        if (smart) {
            // e^x = 2^k * e^r with r in [-ln2/2, ln2/2]
            long k = lround(xo / LN2);
            p.x    = xo - k * LN2;
            p.pow2 = static_cast<int>(k);
        } else if (xo < 0) {
            p.x = -xo;  p.invert = true;
        }
    }
    else if (f == LN && smart) {
        p.series = LN_ATANH;
        p.x      = xo / (2.0 + xo);                          // y
    }
    return p;
}

// Turn a partial sum of the series back into the answer for f(x).
double finalValue(const Plan& p, double sum) {
    double v = p.sign * sum;
    if (p.invert)    v = 1.0 / v;
    if (p.pow2 != 0) v = ldexp(v, p.pow2);                  // v * 2^pow2
    return v;
}

// ---------- Core computation ----------
// Smallest number of terms (up to MAX_TERMS) with error < TOLERANCE.
// Returns 0 if that is never reached.
int termsNeeded(Func f, double xo, bool smart) {
    Plan   p     = prepare(f, xo, smart);
    double exact = exactValue(f, xo);
    double term  = firstTerm(p.series, p.x);
    double sum   = term;
    for (int k = 1; k <= MAX_TERMS; ++k) {
        if (k > 1) { term = nextTerm(p.series, k, term, p.x); sum += term; }
        if (fabs(finalValue(p, sum) - exact) < TOLERANCE) return k;
    }
    return 0;
}

void printCount(const char* label, int n) {
    cout << "    " << left << setw(16) << label << right;
    if (n > 0) cout << n << " term(s)\n";
    else       cout << "not reached in " << MAX_TERMS << " terms\n";
}

void runSeries(Func f, double xo, int terms) {
    Plan   p     = prepare(f, xo, true);
    double exact = exactValue(f, xo);
    double term  = firstTerm(p.series, p.x);
    double sum   = term;

    cout << "\n  Function : " << funcName(f) << "\n";
    cout << "  x        : " << defaultfloat << setprecision(10) << xo << "\n";
    cout << "  Exact    : " << fixed << setprecision(10) << exact
         << "   (from <cmath>)\n";
    cout << "  Smart step: series runs on x' = " << defaultfloat << setprecision(6) << p.x
         << ", sign " << (p.sign < 0 ? "-1" : "+1") << ", scale 2^" << p.pow2 << "\n\n";

    cout << "  " << left  << setw(7)  << "Terms"
         << right << setw(16) << "Term added"
         << setw(18) << "Approximation"
         << setw(16) << "Abs. error" << "\n";
    cout << "  " << string(57, '-') << "\n";

    for (int k = 1; k <= terms; ++k) {
        if (k > 1) {
            term = nextTerm(p.series, k, term, p.x);
            sum += term;
        }
        double approx = finalValue(p, sum);
        double err    = fabs(approx - exact);

        cout << "  " << left << setw(7) << k << right
             << scientific << setprecision(4) << setw(16) << term
             << fixed      << setprecision(10) << setw(18) << approx
             << scientific << setprecision(3)  << setw(16) << err << "\n";
    }
    cout << defaultfloat;

    cout << "\n  Terms needed for error < 1e-6:\n";
    printCount("Classic method:", termsNeeded(f, xo, false));
    printCount("Smart method:",   termsNeeded(f, xo, true));
}

// ---------- Menu ----------
void showMenu() {
    cout << "\n==============================\n"
         << "   APPROXIMA v2\n"
         << "   Taylor Series Calculator\n"
         << "==============================\n"
         << "  1. sin(x)\n"
         << "  2. cos(x)\n"
         << "  3. e^x\n"
         << "  4. ln(1+x)\n"
         << "  5. Exit\n";
}

int main() {
    cout << "Approxima v2: watch the error shrink term by term.\n";

    while (true) {
        showMenu();
        int choice;
        if (!readInt("Choose (1-5): ", 1, 5, choice)) break;
        if (choice == 5) break;

        Func   f = static_cast<Func>(choice);
        double x;

        if (f == SIN || f == COS) {
            int unit;
            if (!readInt("Angle in 1) radians or 2) degrees? ", 1, 2, unit)) break;
            while (true) {
                if (!readDouble("Enter the angle: ", x)) return 0;
                if (unit == 2) x = x * PI / 180.0;
                if (fabs(x) <= 1e6) break;
                cout << "  Angle too large (keep it under 1,000,000 radians).\n";
            }
        }
        else if (f == EXP) {
            while (true) {
                if (!readDouble("Enter x (between -10 and 10): ", x)) return 0;
                if (fabs(x) <= 10.0) break;
                cout << "  Out of range. Use |x| <= 10.\n";
            }
        }
        else { // LN
            while (true) {
                if (!readDouble("Enter x (-1 < x <= 1): ", x)) return 0;
                if (x > -1.0 && x <= 1.0) break;
                cout << "  The series for ln(1+x) only works for -1 < x <= 1.\n";
            }
            if (x < -0.9)
                cout << "  Note: very close to -1 even the smart series needs many terms.\n";
        }

        int terms;
        if (!readInt("Number of terms (1-50): ", 1, MAX_TERMS, terms)) break;

        runSeries(f, x, terms);
    }

    cout << "\nGoodbye!\n";
    return 0;
}